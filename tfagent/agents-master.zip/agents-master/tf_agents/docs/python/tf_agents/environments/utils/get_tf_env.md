<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.environments.utils.get_tf_env" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.environments.utils.get_tf_env

Ensures output is a tf_environment, wrapping py_environments if needed.

``` python
tf_agents.environments.utils.get_tf_env(environment)
```



Defined in [`environments/utils.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/environments/utils.py).

<!-- Placeholder for "Used in" -->
