<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.environments.batched_py_environment.fast_map_structure" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.environments.batched_py_environment.fast_map_structure

List tf.nest.map_structure, but skipping the slow assert_same_structure.

``` python
tf_agents.environments.batched_py_environment.fast_map_structure(
    func,
    *structure
)
```



Defined in [`environments/batched_py_environment.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/environments/batched_py_environment.py).

<!-- Placeholder for "Used in" -->
