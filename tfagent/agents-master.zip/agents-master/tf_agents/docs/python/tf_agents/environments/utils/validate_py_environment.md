<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.environments.utils.validate_py_environment" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.environments.utils.validate_py_environment

Validates the environment follows the defined specs.

``` python
tf_agents.environments.utils.validate_py_environment(
    environment,
    episodes=5
)
```



Defined in [`environments/utils.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/environments/utils.py).

<!-- Placeholder for "Used in" -->
