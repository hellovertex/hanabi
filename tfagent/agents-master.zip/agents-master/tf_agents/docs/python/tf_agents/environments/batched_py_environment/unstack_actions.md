<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.environments.batched_py_environment.unstack_actions" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.environments.batched_py_environment.unstack_actions

Returns a list of actions from potentially nested batch of actions.

``` python
tf_agents.environments.batched_py_environment.unstack_actions(batched_actions)
```



Defined in [`environments/batched_py_environment.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/environments/batched_py_environment.py).

<!-- Placeholder for "Used in" -->
