<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.agents.reinforce" />
<meta itemprop="path" content="Stable" />
</div>

# Module: tf_agents.agents.reinforce

A REINFORCE agent.



Defined in [`agents/reinforce/__init__.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/agents/reinforce/__init__.py).

<!-- Placeholder for "Used in" -->


## Modules

[`reinforce_agent`](../../tf_agents/agents/reinforce/reinforce_agent.md) module: A REINFORCE Agent.

