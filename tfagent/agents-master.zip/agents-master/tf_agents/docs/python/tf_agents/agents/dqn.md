<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.agents.dqn" />
<meta itemprop="path" content="Stable" />
</div>

# Module: tf_agents.agents.dqn

A DQN (Deep Q Network) agent.



Defined in [`agents/dqn/__init__.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/agents/dqn/__init__.py).

<!-- Placeholder for "Used in" -->


## Modules

[`dqn_agent`](../../tf_agents/agents/dqn/dqn_agent.md) module: A DQN Agent.

