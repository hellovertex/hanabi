<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.agents.sac.sac_agent.std_clip_transform" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.agents.sac.sac_agent.std_clip_transform



``` python
tf_agents.agents.sac.sac_agent.std_clip_transform(
    *args,
    **kwargs
)
```

<!-- Placeholder for "Used in" -->
