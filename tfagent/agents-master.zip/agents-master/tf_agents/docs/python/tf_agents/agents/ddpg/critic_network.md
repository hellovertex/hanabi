<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.agents.ddpg.critic_network" />
<meta itemprop="path" content="Stable" />
</div>

# Module: tf_agents.agents.ddpg.critic_network

Sample Critic/Q network to use with DDPG agents.



Defined in [`agents/ddpg/critic_network.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/agents/ddpg/critic_network.py).

<!-- Placeholder for "Used in" -->


## Classes

[`class CriticNetwork`](../../../tf_agents/agents/ddpg/critic_network/CriticNetwork.md): Creates a critic network.

