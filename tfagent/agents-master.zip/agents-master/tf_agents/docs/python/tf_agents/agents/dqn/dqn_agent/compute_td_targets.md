<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.agents.dqn.dqn_agent.compute_td_targets" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.agents.dqn.dqn_agent.compute_td_targets



``` python
tf_agents.agents.dqn.dqn_agent.compute_td_targets(
    next_q_values,
    rewards,
    discounts
)
```



Defined in [`agents/dqn/dqn_agent.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/agents/dqn/dqn_agent.py).

<!-- Placeholder for "Used in" -->
