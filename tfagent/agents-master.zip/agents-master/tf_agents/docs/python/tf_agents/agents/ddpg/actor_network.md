<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.agents.ddpg.actor_network" />
<meta itemprop="path" content="Stable" />
</div>

# Module: tf_agents.agents.ddpg.actor_network

Sample Actor network to use with DDPG agents.



Defined in [`agents/ddpg/actor_network.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/agents/ddpg/actor_network.py).

<!-- Placeholder for "Used in" -->


## Classes

[`class ActorNetwork`](../../../tf_agents/agents/ddpg/actor_network/ActorNetwork.md): Creates an actor network.

