<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.agents.ppo.ppo_utils.get_metric_observers" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.agents.ppo.ppo_utils.get_metric_observers

Returns a list of observers, one for each metric.

``` python
tf_agents.agents.ppo.ppo_utils.get_metric_observers(metrics)
```



Defined in [`agents/ppo/ppo_utils.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/agents/ppo/ppo_utils.py).

<!-- Placeholder for "Used in" -->
