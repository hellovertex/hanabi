<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.agents.sac" />
<meta itemprop="path" content="Stable" />
</div>

# Module: tf_agents.agents.sac

A Soft Actor Critic agent.



Defined in [`agents/sac/__init__.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/agents/sac/__init__.py).

<!-- Placeholder for "Used in" -->


## Modules

[`sac_agent`](../../tf_agents/agents/sac/sac_agent.md) module: A Soft Actor-Critic Agent.

