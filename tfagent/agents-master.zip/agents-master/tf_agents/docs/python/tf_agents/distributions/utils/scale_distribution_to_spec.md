<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.distributions.utils.scale_distribution_to_spec" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.distributions.utils.scale_distribution_to_spec

Scales the given distribution to the bounds of the given spec.

``` python
tf_agents.distributions.utils.scale_distribution_to_spec(
    distribution,
    spec
)
```



Defined in [`distributions/utils.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/distributions/utils.py).

<!-- Placeholder for "Used in" -->
