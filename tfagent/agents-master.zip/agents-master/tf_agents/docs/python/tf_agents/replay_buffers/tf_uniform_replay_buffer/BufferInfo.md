<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.replay_buffers.tf_uniform_replay_buffer.BufferInfo" />
<meta itemprop="path" content="Stable" />
<meta itemprop="property" content="ids"/>
<meta itemprop="property" content="probabilities"/>
<meta itemprop="property" content="__new__"/>
</div>

# tf_agents.replay_buffers.tf_uniform_replay_buffer.BufferInfo

## Class `BufferInfo`

BufferInfo(ids, probabilities)





Defined in [`replay_buffers/tf_uniform_replay_buffer.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/replay_buffers/tf_uniform_replay_buffer.py).

<!-- Placeholder for "Used in" -->


<h2 id="__new__"><code>__new__</code></h2>

``` python
@staticmethod
__new__(
    _cls,
    ids,
    probabilities
)
```

Create new instance of BufferInfo(ids, probabilities)



## Properties

<h3 id="ids"><code>ids</code></h3>



<h3 id="probabilities"><code>probabilities</code></h3>





