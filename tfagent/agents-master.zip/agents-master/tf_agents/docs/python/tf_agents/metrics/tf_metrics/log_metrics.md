<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.metrics.tf_metrics.log_metrics" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.metrics.tf_metrics.log_metrics



``` python
tf_agents.metrics.tf_metrics.log_metrics(
    metrics,
    prefix=''
)
```



Defined in [`metrics/tf_metrics.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/metrics/tf_metrics.py).

<!-- Placeholder for "Used in" -->
