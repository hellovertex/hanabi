<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.trajectories.policy_step.get_log_probability" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.trajectories.policy_step.get_log_probability

Gets the CommonFields.LOG_PROBABILITY from info depending on type.

``` python
tf_agents.trajectories.policy_step.get_log_probability(
    info,
    default_log_probability=None
)
```



Defined in [`trajectories/policy_step.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/trajectories/policy_step.py).

<!-- Placeholder for "Used in" -->
