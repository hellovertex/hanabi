<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.trajectories.time_step.time_step_spec" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.trajectories.time_step.time_step_spec

Returns a `TimeStep` spec given the observation_spec.

``` python
tf_agents.trajectories.time_step.time_step_spec(observation_spec=None)
```



Defined in [`trajectories/time_step.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/trajectories/time_step.py).

<!-- Placeholder for "Used in" -->
