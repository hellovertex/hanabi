<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.utils.test_utils.TestCase.failureException" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.utils.test_utils.TestCase.failureException

## Class `failureException`

Assertion failed.



<!-- Placeholder for "Used in" -->


