<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.utils.eager_utils.clip_gradient_norms_fn" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.utils.eager_utils.clip_gradient_norms_fn

Returns a `transform_grads_fn` function for gradient clipping.

``` python
tf_agents.utils.eager_utils.clip_gradient_norms_fn(max_norm)
```



Defined in [`utils/eager_utils.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/utils/eager_utils.py).

<!-- Placeholder for "Used in" -->
