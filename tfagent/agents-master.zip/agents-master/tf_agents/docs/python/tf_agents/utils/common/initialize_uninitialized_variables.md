<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.utils.common.initialize_uninitialized_variables" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.utils.common.initialize_uninitialized_variables

Initialize any pending variables that are uninitialized.

``` python
tf_agents.utils.common.initialize_uninitialized_variables(
    session,
    var_list=None
)
```



Defined in [`utils/common.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/utils/common.py).

<!-- Placeholder for "Used in" -->
