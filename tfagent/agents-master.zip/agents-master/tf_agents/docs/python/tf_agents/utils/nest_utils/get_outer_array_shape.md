<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.utils.nest_utils.get_outer_array_shape" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.utils.nest_utils.get_outer_array_shape

Batch dims of array's batch dimension `dim`.

``` python
tf_agents.utils.nest_utils.get_outer_array_shape(
    nested_array,
    spec
)
```



Defined in [`utils/nest_utils.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/utils/nest_utils.py).

<!-- Placeholder for "Used in" -->
