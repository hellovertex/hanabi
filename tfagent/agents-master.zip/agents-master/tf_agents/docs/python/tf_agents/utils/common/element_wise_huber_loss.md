<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.utils.common.element_wise_huber_loss" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.utils.common.element_wise_huber_loss



``` python
tf_agents.utils.common.element_wise_huber_loss(
    x,
    y
)
```



Defined in [`utils/common.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/utils/common.py).

<!-- Placeholder for "Used in" -->
