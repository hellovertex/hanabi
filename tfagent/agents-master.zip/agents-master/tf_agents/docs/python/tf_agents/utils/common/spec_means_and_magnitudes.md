<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.utils.common.spec_means_and_magnitudes" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.utils.common.spec_means_and_magnitudes

Get the center and magnitude of the ranges in action spec.

``` python
tf_agents.utils.common.spec_means_and_magnitudes(action_spec)
```



Defined in [`utils/common.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/utils/common.py).

<!-- Placeholder for "Used in" -->
