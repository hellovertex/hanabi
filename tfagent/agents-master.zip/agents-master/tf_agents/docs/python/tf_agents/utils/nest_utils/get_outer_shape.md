<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.utils.nest_utils.get_outer_shape" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.utils.nest_utils.get_outer_shape

Runtime batch dims of tensor's batch dimension `dim`.

``` python
tf_agents.utils.nest_utils.get_outer_shape(
    nested_tensor,
    spec
)
```



Defined in [`utils/nest_utils.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/utils/nest_utils.py).

<!-- Placeholder for "Used in" -->
