<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.utils.eager_utils.has_self_cls_arg" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.utils.eager_utils.has_self_cls_arg

Checks if it is method which takes self/cls as the first argument.

``` python
tf_agents.utils.eager_utils.has_self_cls_arg(func_or_method)
```



Defined in [`utils/eager_utils.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/utils/eager_utils.py).

<!-- Placeholder for "Used in" -->
