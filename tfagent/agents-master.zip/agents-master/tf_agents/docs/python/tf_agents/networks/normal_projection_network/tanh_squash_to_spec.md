<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.networks.normal_projection_network.tanh_squash_to_spec" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.networks.normal_projection_network.tanh_squash_to_spec



``` python
tf_agents.networks.normal_projection_network.tanh_squash_to_spec(
    inputs,
    spec
)
```



Defined in [`networks/normal_projection_network.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/networks/normal_projection_network.py).

<!-- Placeholder for "Used in" -->
