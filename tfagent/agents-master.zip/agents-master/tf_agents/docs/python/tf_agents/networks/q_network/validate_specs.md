<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.networks.q_network.validate_specs" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.networks.q_network.validate_specs

Validates the spec contains a single action.

``` python
tf_agents.networks.q_network.validate_specs(
    action_spec,
    observation_spec
)
```



Defined in [`networks/q_network.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/networks/q_network.py).

<!-- Placeholder for "Used in" -->
