<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.specs.tensor_spec.to_nest_array_spec" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.specs.tensor_spec.to_nest_array_spec

Converted a nest of TensorSpecs to a nest of matching ArraySpecs.

``` python
tf_agents.specs.tensor_spec.to_nest_array_spec(nest_array_spec)
```



Defined in [`specs/tensor_spec.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/specs/tensor_spec.py).

<!-- Placeholder for "Used in" -->
