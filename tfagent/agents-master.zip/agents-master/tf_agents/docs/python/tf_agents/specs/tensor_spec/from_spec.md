<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.specs.tensor_spec.from_spec" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.specs.tensor_spec.from_spec

Maps the given spec into corresponding TensorSpecs keeping bounds.

``` python
tf_agents.specs.tensor_spec.from_spec(spec)
```



Defined in [`specs/tensor_spec.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/specs/tensor_spec.py).

<!-- Placeholder for "Used in" -->
