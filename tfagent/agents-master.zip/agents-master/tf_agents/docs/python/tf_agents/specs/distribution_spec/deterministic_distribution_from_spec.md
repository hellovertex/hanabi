<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.specs.distribution_spec.deterministic_distribution_from_spec" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.specs.distribution_spec.deterministic_distribution_from_spec

Creates a Deterministic distribution_spec from a tensor_spec.

``` python
tf_agents.specs.distribution_spec.deterministic_distribution_from_spec(spec)
```



Defined in [`specs/distribution_spec.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/specs/distribution_spec.py).

<!-- Placeholder for "Used in" -->
