<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tf_agents.policies.tf_py_policy.map_tensor_spec_to_dtypes_list" />
<meta itemprop="path" content="Stable" />
</div>

# tf_agents.policies.tf_py_policy.map_tensor_spec_to_dtypes_list



``` python
tf_agents.policies.tf_py_policy.map_tensor_spec_to_dtypes_list(t_spec)
```



Defined in [`policies/tf_py_policy.py`](https://github.com/tensorflow/agents/tree/master/tf_agents/policies/tf_py_policy.py).

<!-- Placeholder for "Used in" -->
